﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;
using System.Data.SQLite;
using OsmSharp;
using OsmSharp.Osm;
using OsmSharp.Osm.Tiles;
using OsmSharp.Math.Geo;
using BoundingBoxFilter.Classes;
namespace BoundingBoxFilter
{
    class Program
    {
        static void Main(string[] args)
		{
			Arguments Args = new Arguments(args);
			string name_ = ""; string desc_ = null; double NELat_ = 0; double NELong_ = 0; double SWLat_ = 0; double SWLong_ = 0; string RefDB_ = null; string NewDB_ = null;
			int Zoom_ = 0;
			//
			try
			{
				if (Args["Name"] != null) name_ = Args["Name"];
				else throw new Exception("Missing Name parameter!");
				if (Args["Description"] != null) desc_ = Args["Description"];
				else throw new Exception("Missing Description parameter!");
				if (Args["NewDB"] != null) NewDB_ = Args["NewDB"];
				else throw new Exception("Missing NewDB parameter!");
				if (Args["RefDB"] != null) RefDB_ = Args["RefDB"];
				else throw new Exception("Missing RefDB parameter!");
				//
				if (Args["NELat"] != null) {
					if (!double.TryParse(Args["NELat"], out NELat_))
						throw new Exception("Invalid double value for NELat");
				}
				else throw new Exception("Missing NELat parameter!");
				//
				if (Args["NELong"] != null)
				{
					if (!double.TryParse(Args["NELong"], out NELong_))
						throw new Exception("Invalid double value for NELong");
				}
				else throw new Exception("Missing NELong parameter!");
				//
				if (Args["SWLat"] != null)
				{
					if (!double.TryParse(Args["SWLat"], out SWLat_))
						throw new Exception("Invalid double value for SWLat");
				}
				else throw new Exception("Missing SWLat parameter!");
				//
				if (Args["SWLong"] != null)
				{
					if (!double.TryParse(Args["SWLong"], out SWLong_))
						throw new Exception("Invalid double value for SWLong");
				}
				else throw new Exception("Missing SWLong parameter!");
				//
				if (Args["Zoom"] != null)
				{
					if (!int.TryParse(Args["Zoom"], out Zoom_))
						throw new Exception("Invalid integer value for Zoom");
				}
				else throw new Exception("Missing Zoom parameter!");
			}
			catch (Exception ex1)
            {
                DoErrorTrace(ex1);
				Console.Read();
				Environment.Exit(1);
            }
            try
			{
				if (!File.Exists(RefDB_)) throw new Exception($"File {RefDB_} does not exist");
				//
				if (File.Exists(NewDB_)) 
					File.Delete(NewDB_);
				//
				Execute(name_, desc_, NewDB_, RefDB_, NELat_, NELong_, SWLat_, SWLong_, Zoom_);
				//
			}
			catch (Exception ex1)
			{
				DoErrorTrace(ex1);
				Console.Read();
			}
			//
			Console.Read();
		}

        private static void DoErrorTrace(Exception ex1)
        {
            Console.WriteLine("Failed to Read or Process Arguments");
            Console.WriteLine("Call program as follows...");
            Console.WriteLine("BoundingBoxFilter.exe -Name xxxx -Description yyyy -NELat=latitude -NELong=longitude ");
            Console.WriteLine("                                                   -SWLat=latitude -SWLong=longitude ");
            Console.WriteLine("                                                   -NewDB=filename -RefDB=filename ");
            Console.WriteLine("                                                   -Zoom=number ");
            Console.WriteLine(ex1.Message + "\n" + ex1.StackTrace);
        }

        public static void Execute(string name, string description, string newMBTilesFile, string existingMBTilesFile,
			double NorthEastLatitude,double NorthEastLongitude,
			double SouthWestLatitude,double SouthWestLongitude,  int zoomLevel)
		{
			if (File.Exists(newMBTilesFile))
			{
				File.Delete(newMBTilesFile);
			}
			SQLiteConnection.CreateFile(newMBTilesFile);
			using (SQLiteConnection connection = new SQLiteConnection("Data Source=" + newMBTilesFile + ";Version=3;"))
			{
				connection.Open();
				new SQLiteCommand("ATTACH '" + existingMBTilesFile + "' AS EXI", connection).ExecuteNonQuery();
				string createTablesSql = "CREATE TABLE metadata (name text, value text);\r\n                                        CREATE TABLE tiles ('id' integer not null primary key autoincrement, 'zoom_level' integer, 'tile_column' integer, 'tile_row' integer, 'tile_data' blob);";
				new SQLiteCommand(createTablesSql, connection).ExecuteNonQuery();
				string metadataSql = $"INSERT INTO metadata (name, value) VALUES ('name', '{name}');\r\n                    INSERT INTO metadata (name, value) VALUES ('type', 'baselayer');\r\n                    INSERT INTO metadata (name, value) VALUES ('version', '1');\r\n                    INSERT INTO metadata (name, value) VALUES ('minzoom', '1');\r\n                    INSERT INTO metadata (name, value) VALUES ('maxzoom', '{zoomLevel}');\r\n                    INSERT INTO metadata (name, value) VALUES ('version', '1');\r\n                    INSERT INTO metadata (name, value) VALUES ('description', '{description}');\r\n                    INSERT INTO metadata (name, value) VALUES ('bounds', '{NorthEastLongitude},{NorthEastLatitude},{SouthWestLongitude},{SouthWestLatitude}');\r\n                    INSERT INTO metadata (name, value) VALUES ('format', 'png');";
				new SQLiteCommand(metadataSql, connection).ExecuteNonQuery();
				GeoCoordinate ne = new GeoCoordinate(NorthEastLatitude, NorthEastLongitude);
				GeoCoordinate sw = new GeoCoordinate(SouthWestLatitude, SouthWestLongitude);
				int numbercompleted = 0;
				int lastpercent = 0;
				for (int i = 1; i <= zoomLevel; i++)
				{
					TileRange range = TileRange.CreateAroundBoundingBox(new GeoCoordinateBox(ne, sw), i);
					IEnumerable<Tile> tiles = range.Select((Tile tile) => tile.InvertY());
					string x = string.Join(",", tiles.Select((Tile tile) => tile.X));
					string y = string.Join(",", tiles.Select((Tile tile) => tile.Y));
					using (SQLiteTransaction transaction = connection.BeginTransaction())
					{ 
						string mapsSql = $"INSERT INTO tiles (zoom_level, tile_column, tile_row, tile_data)\r\n                            SELECT zoom_level, tile_column, tile_row, tile_data FROM EXI.tiles \r\n                            WHERE EXI.tiles.zoom_level = {i}\r\n                            AND EXI.tiles.tile_column IN ({x})\r\n                            AND EXI.tiles.tile_row IN ({y})";
						new SQLiteCommand(mapsSql, connection).ExecuteNonQuery();
						numbercompleted++;
						int newpercent = (int)Math.Round((double)numbercompleted / (double)zoomLevel * 100.0);
						if (newpercent != lastpercent)
						{ 
							lastpercent = newpercent;
						}
						transaction.Commit();
					}
				}
				string createIndicesSql = "\r\n                    CREATE INDEX tiles_zoom_level on tiles (zoom_level); \r\n                    CREATE INDEX tiles_tile_column on tiles (tile_column); \r\n                    CREATE INDEX tiles_tile_row on tiles (tile_row)\r\n                ";
				new SQLiteCommand(createIndicesSql, connection).ExecuteNonQuery();
				connection.Close();
			}
		}
	}
}
