Call program as follows...
BoundingBoxFilter.exe -Name xxxx -Description yyyy -NELat=latitude -NELong=longitude
                                                   -SWLat=latitude -SWLong=longitude
                                                   -NewDB=filename -RefDB=filename
                                                   -Zoom=number

e.g.
BoundingBoxFilter.exe -Name="A new File" -Description="Containing some files" -NELat=51.698 -NELong=0.2994 -SWLat=51.2636 -SWLong=-0.6180 -NewDB="D:\Seagate Backup\Tiles\Output.mbtiles" -RefDB="D:\Seagate Backup\Tiles\gb_southeast_merged_zl17.mbtiles" -Zoom=16


BoundingBoxFilter.exe -Name="A new File" -Description="London September 2021 ZL17" -NELat=51.88599 -NELong=-0.82054 -SWLat=51.13646 -SWLong=0.47585 -NewDB="C:\Offline Tiles Q2 2021\4. boudning box versions\uk_3_London_september_2021_ZL17.mbtiles" -RefDB="C:\Offline Tiles Q2 2021\3. base versions\uk_september_2021_ZL17.mbtiles" -Zoom=17

