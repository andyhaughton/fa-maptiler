# Earthware MBTiles Utils #

This is a collection of utilities written in c# for creating and managing mbtile files https://github.com/mapbox/mbtiles-spec

## Mbtile Downloader ###
This console app downloads png files from any xyz web mapping tile server url into an mbtiles file. In the app.config you can set one or more tile server urls, a bounding box for the area of the world you want to generate and the min and max zoom levels. 

The downloader can restart without losing any work but will take 2-3 days to generate the UK down to zoom level 16 from a fast local tile server even with parallel processing.

Tiles are fist downloaded to a local directory then inserted into the mbtiles file so after the process has finished and you have checked the file works you can delete the images.

## Mbtile optimizer ###
This console app helps to reduce the size of mbtile files by finding duplicate images (like sea tiles) and modifying the mbtile database schema so that all duplicates can point to a single BLOB. In the app.config you can specify an input mbtile file, and output mbtile file name (it will create it each time the optimize runs) and a single (for now) example of a file to find duplicates for as well as enable and disable de-duplication.

This can also compress the png files to 8-bit saving some space, this can also be enabled and disabled in the app.config. Png compression will significantly slow down the optimizer.


**WARNING** because it changes the schema of the database, and uses a view to make the "tiles" table look like the mbtiles spec the mbtile file generated may not be 100% compatible with other mbtile systems.

## Mbtile boundingbox filter ##
This WPF application takes an input mbtiles file and allows you to specify an area (bounding box) and max zoom level then allows you to create a new mbtiles file with a subset of the input file filtered by the bounding box and zoom level. 

Currently the application is distributed via clickonce (use publish in visual studio to a local folder then upload to azure storage account at https://earthwaredownloads.blob.core.windows.net) which can then be installed by visiting https://earthwaredownloads.blob.core.windows.net/mbtilesfilter/publish.htm 
