﻿$LinuxIP    = "18.170.64.61"      #Replace with public IP of linux server
$Month      = "September"         #Replace with currentg month
$Year       = "2021"              #Replace with current year
$Quarter    = "Q3"                #Replace with current quarter
$RootFolder = "C:\Offline Tiles\"
$Subfolder  = "$($Quarter) $($Month) $($Year)"
$ZL1        = "17"
$ZL2        = "14"
$TileServer = "http://$($LinuxIP):8080"


#Create folder structure
If(!(Test-Path -Path $RootFolder$SubFolder))
{
    New-Item -Path $RootFolder$SubFolder -Name "1. source vector files"   -ItemType "Directory"
    New-Item -Path $RootFolder$SubFolder -Name "2. downloaded tiles"      -ItemType "Directory"
    New-Item -Path $RootFolder$SubFolder -Name "3. base versions"         -ItemType "Directory"
    New-Item -Path $RootFolder$SubFolder -Name "4. bounding box versions" -ItemType "Directory"
    New-Item -Path $RootFolder$SubFolder -Name "5. merged versions"       -ItemType "Directory"
    New-Item -Path $RootFolder$SubFolder -Name "6. production versions"   -ItemType "Directory"
}


#Install Posh-SSH (used to send commands to Linux server)
Set-ExecutionPolicy RemoteSigned -Force
Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
Install-Module Posh-SSH -force 
Import-module Posh-SSH


#Setup linux server credentials
$User       = "ec2-user"
$Pass       = "ec2-user"
$SecurePass = ConvertTo-SecureString $Pass -AsPlainText -Force
$Creds      = New-Object System.Management.Automation.PSCredential ($User,$SecurePass)


#Connect to Linux server
$Session = New-SSHSession $LinuxIP -KeyFile C:\Scripts\config\Putty\key.pem -Credential $Creds
#Start Docker Service
Invoke-SSHCommand -SSHSession $session 'sudo service docker start'
#Download latest mbtiles from maptiler replace https:// with full url copied from website
Invoke-SSHCommand -SSHSession $session 'wget -c https://data.maptiler.com/my-extracts/get/.eJyLVjKAAl0sBBgYJaYp6RhZmFkaxQIA0r4JUQ.YYOQ_Q.OB5scXG-jKcwJXe2LzXl8kgJLd4/maptiler-osm-2021-10-18-v3.12.2-europe_british-isles.mbtiles'
#Start the Maptiler Docker Container
Invoke-SSHCommand -SSHSession $session 'docker run -d --rm -it -v $(pwd):/data -p 8080:80 maptiler/tileserver-gl'


#1. source vector files
$ls = Invoke-SSHCommand -SSHSession $session 'ls /home/ec2-user'
Get-SCPItem -computername  $LinuxIP -Path "/home/ec2-user/$($ls.output)" -Destination "$($RootFolder)$($Subfolder)\1. source vector files" -PathType File -KeyFile 'C:\Scripts\config\Putty\key.pem' -Credential $Creds


#2. downloaded tiles
$apppath  = 'C:\maptiler\mbtiles-downloader\app.config'
[xml]$xml = Get-Content $apppath
$url      = $xml.configuration.appSettings.add | Where-Object {$_.Key -eq 'tileserverurls'}
$dir      = $xml.configuration.appSettings.add   | Where-Object {$_.Key -eq 'outputdir'}
$file     = $xml.configuration.appSettings.add   | Where-Object {$_.Key -eq 'mbtilesfilename'}
$zoom     = $xml.configuration.appSettings.add   | Where-Object {$_.Key -eq 'maxzoom'}
$xml.configuration.appSettings.RemoveChild($url) | Out-Null
$xml.configuration.appSettings.RemoveChild($dir) | Out-Null
$xml.configuration.appSettings.RemoveChild($file) | Out-Null
$xml.configuration.appSettings.RemoveChild($zoom) | Out-Null
$url.value  = "$($TileServer)/styles/basic-preview/{z}/{x}/{y}.png"
$dir.value  = "$($RootFolder)$($Subfolder)\2. downloaded tiles"
$file.value = "UK_$($Month)_$($Year)_ZL$($ZL1).mbtiles"
$zoom.value = $ZL1
$xml.configuration.appSettings.AppendChild($url) | Out-Null
$xml.configuration.appSettings.AppendChild($dir) | Out-Null
$xml.configuration.appSettings.AppendChild($file) | Out-Null
$xml.configuration.appSettings.AppendChild($zoom) | Out-Null
$xml.Save($apppath)

$apppath  = "C:\maptiler\mbtiles-downloader\bin\Release\mbtiles-downloader.exe.config"
[xml]$xml = Get-Content $apppath
$url      = $xml.configuration.appSettings.add | Where-Object {$_.Key -eq 'tileserverurls'}
$dir      = $xml.configuration.appSettings.add   | Where-Object {$_.Key -eq 'outputdir'}
$file     = $xml.configuration.appSettings.add   | Where-Object {$_.Key -eq 'mbtilesfilename'}
$zoom     = $xml.configuration.appSettings.add   | Where-Object {$_.Key -eq 'maxzoom'}
$xml.configuration.appSettings.RemoveChild($url) | Out-Null
$xml.configuration.appSettings.RemoveChild($dir) | Out-Null
$xml.configuration.appSettings.RemoveChild($file) | Out-Null
$xml.configuration.appSettings.RemoveChild($zoom) | Out-Null
$url.value  = "$($TileServer)/styles/basic-preview/{z}/{x}/{y}.png"
$dir.value  = "$($RootFolder)$($Subfolder)\2. downloaded tiles"
$file.value = "UK_$($Month)_$($Year)_ZL$($ZL1).mbtiles"
$zoom.value = $ZL1
$xml.configuration.appSettings.AppendChild($url) | Out-Null
$xml.configuration.appSettings.AppendChild($dir) | Out-Null
$xml.configuration.appSettings.AppendChild($file) | Out-Null
$xml.configuration.appSettings.AppendChild($zoom) | Out-Null
$xml.Save($apppath)

$DLProcess = "C:\maptiler\mbtiles-downloader\bin\Release\mbtiles-downloader.exe"
Start-Process $DLProcess -Wait
Move-Item "$($RootFolder)\$($Subfolder)\2. downloaded tiles$($file.value)" "$($RootFolder)$($Subfolder)\3. base versions\UK_$($Month)_$($Year)_ZL$($ZL1).mbtiles"


#3. base versions
$apppath  = 'C:\maptiler\mbtiles-creator v4\mbtiles-creator.exe.config'
[xml]$xml = Get-Content $apppath
$root     = $xml.configuration.appSettings.add   | Where-Object {$_.Key -eq 'TilesRoot'}
$zoom     = $xml.configuration.appSettings.add   | Where-Object {$_.Key -eq 'MaxZoomLevel'}
$xml.configuration.appSettings.RemoveChild($root) | Out-Null
$xml.configuration.appSettings.RemoveChild($zoom) | Out-Null
$root.value = $dir.value
$zoom.value = $ZL2
$xml.configuration.appSettings.AppendChild($root) | Out-Null
$xml.configuration.appSettings.AppendChild($zoom) | Out-Null
$xml.Save($apppath)

$CRProcess = "C:\maptiler\mbtiles-creator v4\mbtiles-creator.exe"
Start-Process $CRProcess -wait
Move-Item "C:\maptiler\mbtiles-creator v4\Output.mbtiles" "$($RootFolder)$($Subfolder)\3. base versions\UK_$($Month)_$($Year)_ZL$($ZL2).mbtiles"


#4. bounding box versions
$BBProcess = "C:\maptiler\mbtiles-boundingboxfilter v2\bin\Debug\BoundingBoxFilter.exe"
$Regions   = Import-CSV -Path 'C:\maptiler\scripts\regions.csv'
ForEach($Region in $Regions)
{
    $args =  "-Name=""$($Region.name)"" -Description=""$($Region.Description)"" -NELat=$($Region.NELat) -NELong=$($Region.NELong) -SWLat=$($Region.SWLat) -SWLong=$($Region.SWLong) -NewDB=""$($RootFolder)$($Subfolder)\4. boudning box versions\$($region.name)"" -RefDB=""$($RootFolder)$($Subfolder)\3. base versions\UK_$($Month)_$($Year)_ZL17.mbtiles"" -Zoom=$($Region.ZL)"
    start-Process $BBProcess -ArgumentList $args -wait

}


#5. merged versions
$MProcess = '"C:\maptiler\mbtiles-merger\mbtiles-merger.exe"'
$Regions  = Import-CSV -Path 'C:\maptiler\scripts\regions.csv'
$Base     = "$($RootFolder)$($Subfolder)\3. base versions\UK_$($Month)_$($Year)_ZL$($ZL2).mbtiles"
$Out      = "$($RootFolder)$($Subfolder)\5. merged versions\"
ForEach($Region in $Regions)

{
    $args =  "-f""$($Base)"" -s""$($RootFolder)$($Subfolder)\4. boudning box versions\$($region.name)"" -o""$($Out)$($Region.Name)"""
    start-Process $MProcess -ArgumentList $args
    $wshell = New-Object -ComObject wscript.shell;
    $wshell.AppActivate('mbtiles-merger')
    Sleep 10
    $wshell.SendKeys('~')

}


#6. production versions
$apppath  = 'C:\maptiler\mbtiles-new-optimizer\mbtiles-new-optimizer.exe.config'
$In       = "C:\Offline Tiles Q2 2021\5. merged versions\"
$Out      = "C:\Offline Tiles Q2 2021\6. production versions\"
$files    = Get-ChildItem -path $in
$PProcess = '"C:\maptiler\mbtiles-new-optimizer\mbtiles-new-optimizer.exe"'


ForEach($File in $Files)
{

    [xml]$xml = Get-Content $apppath
    $Source = $xml.configuration.appSettings.add | Where-Object {$_.Key -eq 'SourceMbTiles'}
    $Dest   = $xml.configuration.appSettings.add   | Where-Object {$_.Key -eq 'DestinationMbTiles'}
    $xml.configuration.appSettings.RemoveChild($Source) | Out-Null
    $Source.value = $File.FullName
    $xml.configuration.appSettings.AppendChild($Source) | Out-Null
    $xml.configuration.appSettings.RemoveChild($Dest) | Out-Null
    $Dest.Value = "$($Out)$($File.Name)"
    $xml.configuration.appSettings.AppendChild($Dest) | Out-Null
    $xml.Save($apppath)
    Start-Process $PProcess
    $wshell = New-Object -ComObject wscript.shell;
    $wshell.AppActivate('mbtiles-optimizer')
    Sleep 10
    $wshell.SendKeys('~')
} 
