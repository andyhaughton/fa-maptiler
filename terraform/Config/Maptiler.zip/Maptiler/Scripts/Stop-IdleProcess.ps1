﻿#Monitor and Stop Idle Process
function Stop-IdleProcess
{
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]
        $ProcessName,

        [int]
        $SleepTime = 10
    )

    # Get the list of initial processes
    $initialProcesses = (Get-Process -Name $ProcessName -ErrorAction SilentlyContinue | Select-Object NPM, CPU, Id)

    # If there are no processes, return
    if (($initialProcesses | Measure-Object).Count -eq 0)
    {
        Write-Host "No processes found for $ProcessName"
        return
    }

    # Sleep for a period of time
    Start-Sleep -Seconds $SleepTime

    # Now refetch the list of processes
    $newProcesses = (Get-Process -Name $ProcessName -ErrorAction SilentlyContinue | Select-Object NPM, CPU, Id)

    # If there are no processes, then they've all finished so none idle
    if (($newProcesses | Measure-Object).Count -eq 0)
    {
        Write-Host "All $ProcessName processes have finished"
        return
    }

    # Otherwise, we need to find process with the same ID/NPM and CPU, as these are idle/crashed
    foreach ($new in $newProcesses)
    {
        # Find the process from the initial ones
        $match = $initialProcesses | Where-Object { $_.NPM -eq $new.NPM -and $_.CPU -eq $new.CPU -and $_.Id -eq $new.Id } | Select-Object -First 1

        # If there isn't one, continue
        if ($match -eq $null)
        {
            continue
        }

        # Otherwise, stop the process as it's crashed
        Write-Host "Stopping $ProcessName process with ID: $($match.Id)"
        Stop-Process -Id $match.Id -Force | Out-Null
    }
}

Stop-IdleProcess -ProcessName mbtiles-creator
Stop-IdleProcess -ProcessName boundingboxfilter
Stop-IdleProcess -ProcessName mbtiles-merger
Stop-IdleProcess -ProcessName mbtiles-new-optimizer

