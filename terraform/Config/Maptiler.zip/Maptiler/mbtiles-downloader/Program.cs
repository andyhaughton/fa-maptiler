﻿using OsmSharp.Math.Geo;
using OsmSharp.Osm.Tiles;
using System;
using System.Data;
using System.Data.SQLite;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using System.Configuration;
using System.Threading;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;

namespace mbtilesdownloader
{
    class Program
    {
        private static bool retry10Secs = Convert.ToBoolean(ConfigurationManager.AppSettings["retry10Secs"]);
        private static bool retry10Mins = Convert.ToBoolean(ConfigurationManager.AppSettings["retry10Mins"]);
        private static bool takeLocalCopy = Convert.ToBoolean(ConfigurationManager.AppSettings["takeLocalCopy"]);
        private static int sizeOfSQLInsertList = Convert.ToInt16(ConfigurationManager.AppSettings["sizeOfSQLInsertList"]);
        private static List<SaveTile> lstLocalCopyTiles = new List<SaveTile>();

        static void Main(string[] args)
        {
            var outputDir = ConfigurationManager.AppSettings["outputdir"];
            var mbtilesFile = outputDir + ConfigurationManager.AppSettings["mbtilesfilename"];
            var mbtiles = new SQLiteConnection(string.Format("Data Source={0};Version=3;", mbtilesFile));

            try
            {
                OsmSharp.Logging.Log.Enable();
                OsmSharp.Logging.Log.RegisterListener(new OsmSharp.WinForms.UI.Logging.ConsoleTraceListener());

                // check mbtiles already exists and continue if it does or create new if not
                var dbexistedonstart = File.Exists(mbtilesFile);
                if (takeLocalCopy)
                {
                    //Delete DB if it exists otherwise would have to do a check to see if tile exists before adding it to DB
                    dbexistedonstart = false;
                }

                if (!dbexistedonstart)
                {
                    SQLiteConnection.CreateFile(mbtilesFile);
                }

                mbtiles.Open();

                if (!dbexistedonstart)
                {
                    using (var setupquery = new SQLiteCommand(mbtiles))
                    {
                        setupquery.CommandText = "CREATE TABLE metadata (name text, value text);";
                        setupquery.ExecuteNonQuery();
                        new SQLiteCommand(mbtiles);
                        setupquery.CommandText = "CREATE TABLE tiles (zoom_level integer, tile_column integer, tile_row integer, tile_data blob);";
                        setupquery.ExecuteNonQuery();
                        //setup column index
                        setupquery.CommandText = @"CREATE INDEX tiles_z on tiles (zoom_level);
                    CREATE INDEX tiles_x on tiles (tile_column);
                    CREATE INDEX tiles_y on tiles (tile_row);";
                        setupquery.ExecuteNonQuery();

                        setupquery.CommandText = "INSERT INTO metadata (name, value) VALUES ('name', 'tiles');" +
                            "INSERT INTO metadata (name, value) VALUES ('type', 'baselayer');" +
                            "INSERT INTO metadata (name, value) VALUES ('version', '1');" +
                            "INSERT INTO metadata (name, value) VALUES ('minzoom', '5');" +
                            "INSERT INTO metadata (name, value) VALUES ('maxzoom', '6');" +
                            "INSERT INTO metadata (name, value) VALUES ('version', '1');" +
                            "INSERT INTO metadata (name, value) VALUES ('description', 'A description of this layer');" +
                            "INSERT INTO metadata (name, value) VALUES ('bounds', '-5.2294921875,42.195968776291780,8.50341796875,51.248163159055906');" +
                            "INSERT INTO metadata (name, value) VALUES ('format', 'png');";
                        setupquery.ExecuteNonQuery();
                    }
                }

                var urls = ConfigurationManager.AppSettings["tileserverurls"].Split(',');
                var boxcoordinates = ConfigurationManager.AppSettings["boundingbox"].Split(',');
                var box = new GeoCoordinateBox(
                    new GeoCoordinate(Convert.ToDouble(boxcoordinates[0]), Convert.ToDouble(boxcoordinates[1])),
                    new GeoCoordinate(Convert.ToDouble(boxcoordinates[2]), Convert.ToDouble(boxcoordinates[3])));
                var minZoom = Convert.ToInt16(ConfigurationManager.AppSettings["minzoom"]);
                var maxZoom = Convert.ToInt16(ConfigurationManager.AppSettings["maxzoom"]);
                //Ignore downloaded files
                bool ignoreDownloadedFiles = Convert.ToBoolean(ConfigurationManager.AppSettings["ignoreDownloadedFiles"]);
                //If takign copy of local tiles to DB then ignoreDownloadFiles flag should be false.
                if (takeLocalCopy)
                {
                    ignoreDownloadedFiles = false;
                }

                //Find last zoom directory used if ignoreDownloadedFiles = true
                short lastZoom = minZoom;

                if (ignoreDownloadedFiles)
                {
                    if (Directory.GetDirectories(outputDir).Length > 0)
                    {
                        List<Int16> zoomList = new List<Int16>();

                        foreach (string s in Directory.GetDirectories(outputDir))
                        {
                            zoomList.Add(Convert.ToInt16(new DirectoryInfo(s).Name));
                        }

                        zoomList.Sort();
                        Int16[] i = zoomList.ToArray();

                        lastZoom = i[i.Length - 1];
                    }
                }

                for (var zoom = minZoom; zoom <= maxZoom; zoom++)
                {
                    var tileRange = TileRange.CreateAroundBoundingBox(box, zoom);
                    OsmSharp.Logging.Log.TraceEvent(string.Empty, OsmSharp.Logging.TraceEventType.Information,
                        string.Format("Downloading {0} tiles at zoom {1}.",
                            tileRange.Count, zoom));

                    var startTime = DateTime.UtcNow;

                    var tilesDownloadedCount = 0;
                    var originalZLTileCount = tileRange.Count;

                    if (!ignoreDownloadedFiles || (ignoreDownloadedFiles && Convert.ToInt16(zoom) >= lastZoom))
                    {
                        if (ignoreDownloadedFiles)
                        {
                            int lastX = tileRange.XMax;
                            int lastY = tileRange.YMin;

                            if (Directory.GetDirectories(Path.Combine(outputDir, lastZoom.ToString())).Length > 0)
                            {
                                List<int> XList = new List<int>();
                                foreach (string XDirectory in Directory.GetDirectories(Path.Combine(outputDir, lastZoom.ToString())))
                                {
                                    XList.Add(Convert.ToInt32(new DirectoryInfo(XDirectory).Name));
                                }
                                XList.Sort();
                                int[] XArray = XList.ToArray();
                                string XFolder = XArray[XArray.Length - 1].ToString();
                                lastX = Convert.ToInt32(XFolder);

                                if (Directory.GetFiles(Path.Combine(outputDir, lastZoom.ToString(), XFolder)).Length > 0)
                                {
                                    List<int> YList = new List<int>();
                                    foreach (string YFile in Directory.GetFiles(Path.Combine(outputDir, lastZoom.ToString(), XFolder)))
                                    {
                                        YList.Add(Convert.ToInt32(new FileInfo(YFile).Name.Replace(".png", "")));
                                    }
                                    YList.Sort();
                                    int[] YArray = YList.ToArray();

                                    if (lastX == tileRange.XMax)
                                    {
                                        lastY = YArray[YArray.Length - 1];
                                        if (lastY < tileRange.YMax)
                                        {
                                            lastY++;
                                        }
                                    }


                                    TileRange tileRange2 = new TileRange(tileRange.XMin, lastY, tileRange.XMax, tileRange.YMax, zoom);
                                    if (tileRange2.Count < tileRange.Count)
                                    {
                                        tilesDownloadedCount = tileRange.Count - tileRange2.Count;
                                    }
                                    tileRange = tileRange2;
                                }
                            }
                        }

                        foreach (Tile tile in tileRange)
                        {
                            var tileDir = new DirectoryInfo(Path.Combine(outputDir,
                                                    tile.Zoom.ToString(), tile.X.ToString()));
                            var tileFile = new FileInfo(Path.Combine(tileDir.ToString(),
                                tile.Y.ToString() + ".png"));

                            var inverted = tile.InvertY();
                            byte[] tileImage = null;
                            // check if already downloaded
                            if (!tileFile.Exists)
                            {
                                // download tile.
                                var data = Download(urls[tilesDownloadedCount % urls.Length], tile, 0, 0);

                                // save tile.

                                if (!tileDir.Exists)
                                { // creates target dir.
                                    tileDir.Create();
                                }

                                using (var outputStream = tileFile.OpenWrite())
                                {
                                    outputStream.Write(data, 0, data.Length);
                                }

                                tileImage = data;
                            }
                            else if (takeLocalCopy)
                            {
                                using (FileStream tileImageFile = new FileStream(tileFile.FullName, FileMode.Open, FileAccess.Read))
                                {
                                    tileImage = ReadToEnd(tileImageFile);
                                }
                            }

                            if (tileImage != null)
                            {
                                //Save tile to Insert list
                                SaveTile tileItem = new SaveTile();
                                tileItem.ZoomLevel = zoom;
                                tileItem.TileColumn = tile.X;
                                tileItem.TileRow = inverted.Y;
                                tileItem.TileData = tileImage;
                                lstLocalCopyTiles.Add(tileItem);
                                
                            }
                            tilesDownloadedCount++;
                            // reduce logging to every 1000 tiles
                            if (tilesDownloadedCount % 1000 == 0 && originalZLTileCount > 0)
                            {
                                OsmSharp.Logging.Log.TraceEvent(string.Empty, OsmSharp.Logging.TraceEventType.Information,
                                                    string.Format("Completed {0}% at zoom {1}", Math.Round((decimal)((double)tilesDownloadedCount / originalZLTileCount) * 100), zoom));
                            }

                            if ((tilesDownloadedCount % sizeOfSQLInsertList == 0) || tilesDownloadedCount == originalZLTileCount)
                            {
                                saveLocalTilesToDB(mbtiles);
                                lstLocalCopyTiles.Clear();
                            }
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                if(lstLocalCopyTiles.Count > 0)
                {
                    saveLocalTilesToDB(mbtiles);
                }
                throw new Exception(ex.Message, ex.InnerException);
            }
            finally
            {
                mbtiles.Close();
            }
        }

        private static byte[] getTileImageFromDB(SQLiteConnection mbtiles, short zoom, int x, int y)
        {
            byte[] image = null;

            string sql = $"SELECT tile_data FROM tiles WHERE zoom_level = { zoom } AND tile_column = {x} AND tile_row = {y} LIMIT 1";
            using (var query = new SQLiteCommand(sql, mbtiles))
            {
                using (SQLiteDataReader rdr = query.ExecuteReader())
                {
                    using (DataTable dt = new DataTable())
                    {
                        dt.Load(rdr);
                        if (dt.Rows.Count > 0)
                        {
                            image = (byte[])dt.Rows[0]["tile_data"];
                        }
                    }
                }
            }

            return image;
        }

        private static bool tileImageExists(SQLiteConnection mbtiles, short zoom, int x, int y)
        {
            bool exists = false;

            string sql = $"SELECT * FROM tiles WHERE zoom_level = { zoom } AND tile_column = {x} AND tile_row = {y}";
            using (var query = new SQLiteCommand(sql, mbtiles))
            {
                using (SQLiteDataReader rdr = query.ExecuteReader())
                {
                    using (DataTable dt = new DataTable())
                    {
                        dt.Load(rdr);
                        if(dt.Rows.Count > 0)
                        {
                            exists = true;
                        }
                    }
                }
            }

            return exists;
        }

        private static void saveLocalTilesToDB(SQLiteConnection mbtiles)
        {
            using (var query = new SQLiteCommand(mbtiles))
            {
                using (var transaction = mbtiles.BeginTransaction())
                {
                    foreach (SaveTile SaveTile in lstLocalCopyTiles)
                    {
                        query.CommandText = "INSERT INTO tiles VALUES (:zoom_level, :tile_column, :tile_row, :tile_data) ;";
                        query.Parameters.Add(new SQLiteParameter(@"zoom_level", DbType.Int64));
                        query.Parameters.Add(new SQLiteParameter(@"tile_column", DbType.Int64));
                        query.Parameters.Add(new SQLiteParameter(@"tile_row", DbType.Int64));
                        query.Parameters.Add(new SQLiteParameter(@"tile_data", DbType.Binary));
                        query.Parameters[0].Value = SaveTile.ZoomLevel;
                        query.Parameters[1].Value = SaveTile.TileColumn;
                        query.Parameters[2].Value = SaveTile.TileRow;
                        query.Parameters[3].Value = SaveTile.TileData;
                        query.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
            }
    }

        private static byte[] Download(string url, Tile tile, int tenSecsCount, int tenMinutesCount)
        {
            Exception throwException = null;
            byte[] returnValue = null; 
            try
            {
                // load the tile.
                url = url.Replace("{z}", tile.Zoom.ToString())
                        .Replace("{x}", tile.X.ToString())
                        .Replace("{y}", tile.Y.ToString());

                var request = (HttpWebRequest)HttpWebRequest.Create(
                                    url);
                request.Accept = "text/html, image/png, image/jpeg, image/gif, */*";
                request.UserAgent = "OsmSharp/4.0";

                // OsmSharp.Logging.Log.TraceEvent(string.Empty, TraceEventType.Information, "Request tile@" + url);
            
                returnValue = ReadToEnd(request.GetResponse().GetResponseStream());
            }
            catch (Exception ex)
            {
                throwException = ex;
                //try to download again, try after every 10 secs for 10 times
                if (retry10Secs && tenSecsCount < 10)
                {
                    Thread.Sleep(10000);
                    tenSecsCount++;
                    Download(url, tile, tenSecsCount, tenMinutesCount);
                }
                //if download does not work after 10 attempts of 10 secs then try every 10 minute for 10 times
                else if (retry10Mins && tenMinutesCount < 10)
                {
                    Thread.Sleep(600000);
                    tenMinutesCount++;
                    Download(url, tile, tenSecsCount, tenMinutesCount);
                }
            }
            //if download was unsuccessful then throwi the original exception
            if (returnValue == null)
            {
                throw new Exception(throwException.Message, throwException.InnerException);
            }
            //if download was successful then return object
            else
            {
                return returnValue;
            }
        }

        public static byte[] ReadToEnd(System.IO.Stream stream)
        {
            long originalPosition = 0;

            if (stream.CanSeek)
            {
                originalPosition = stream.Position;
                stream.Position = 0;
            }

            try
            {
                byte[] readBuffer = new byte[4096];

                int totalBytesRead = 0;
                int bytesRead;

                while ((bytesRead = stream.Read(readBuffer, totalBytesRead, readBuffer.Length - totalBytesRead)) > 0)
                {
                    totalBytesRead += bytesRead;

                    if (totalBytesRead == readBuffer.Length)
                    {
                        int nextByte = stream.ReadByte();
                        if (nextByte != -1)
                        {
                            byte[] temp = new byte[readBuffer.Length * 2];
                            Buffer.BlockCopy(readBuffer, 0, temp, 0, readBuffer.Length);
                            Buffer.SetByte(temp, totalBytesRead, (byte)nextByte);
                            readBuffer = temp;
                            totalBytesRead++;
                        }
                    }
                }

                byte[] buffer = readBuffer;
                if (readBuffer.Length != totalBytesRead)
                {
                    buffer = new byte[totalBytesRead];
                    Buffer.BlockCopy(readBuffer, 0, buffer, 0, totalBytesRead);
                }
                return buffer;
            }
            finally
            {
                if (stream.CanSeek)
                {
                    stream.Position = originalPosition;
                }
            }
        }
    }

    internal class SaveTile
    {
        public long ZoomLevel { get; set; }
        public long TileColumn { get; set; }
        public long TileRow { get; set; }

        public byte[] TileData { get; set; }
    }
}
